/**
 * Siana Jeddah VIP - Automated GitHub Uploader
 * 
 * Usage:
 *   agy-node upload_to_github.js <GITHUB_TOKEN> [REPO_NAME] [REPO_OWNER] [BRANCH]
 * Or with environment variables:
 *   GITHUB_TOKEN=your_token node upload_to_github.js
 */

const fs = require('fs');
const path = require('path');
const https = require('https');

const token = process.argv[2] || process.env.GITHUB_TOKEN;
const REPO_NAME = process.argv[3] || process.env.GITHUB_REPO || 'siana-jeddah-vip';
let REPO_OWNER = process.argv[4] || process.env.GITHUB_OWNER || 'zayndaric';
const BRANCH = process.argv[5] || process.env.GITHUB_BRANCH || 'main';

if (!token) {
  console.log(`
========================================================================
  [!] GitHub Token Required
========================================================================
  
  To upload your project to GitHub using this script:
  
  1. Go to https://github.com/settings/tokens (Personal Access Tokens -> Classic)
  2. Generate a token with the 'repo' scope.
  3. Create your repository at https://github.com/new (e.g. name it '${REPO_NAME}')
  4. Run this command:
  
     node upload_to_github.js <YOUR_TOKEN> ${REPO_NAME} ${REPO_OWNER}
     
  Alternatively, you can upload using standard Git:
     git init
     git add .
     git commit -m "Initial commit"
     git branch -M main
     git remote add origin https://github.com/${REPO_OWNER}/${REPO_NAME}.git
     git push -u origin main
========================================================================
`);
  process.exit(1);
}

const PROJECT_DIR = __dirname;
const IGNORED_FILES = new Set([
  'upload_to_github.js',
  '.git',
  '.vercel',
  'node_modules',
  '.DS_Store',
  'Thumbs.db'
]);

function getAllFiles(dir, baseDir = '') {
  let results = [];
  const list = fs.readdirSync(dir);
  for (const file of list) {
    if (IGNORED_FILES.has(file)) continue;
    const fullPath = path.join(dir, file);
    const relPath = path.join(baseDir, file).replace(/\\/g, '/');
    const stat = fs.statSync(fullPath);
    if (stat && stat.isDirectory()) {
      results = results.concat(getAllFiles(fullPath, relPath));
    } else {
      results.push({ fullPath, relPath });
    }
  }
  return results;
}

function githubRequest(method, apiPath, body = null) {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'api.github.com',
      port: 443,
      path: apiPath,
      method: method,
      headers: {
        'User-Agent': 'SianaJeddah-Uploader',
        'Authorization': `Bearer ${token}`,
        'Accept': 'application/vnd.github.v3+json',
        'Content-Type': 'application/json'
      }
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => { data += chunk; });
      res.on('end', () => {
        try {
          const json = JSON.parse(data);
          resolve({ status: res.statusCode, data: json });
        } catch (e) {
          resolve({ status: res.statusCode, data });
        }
      });
    });

    req.on('error', reject);
    if (body) {
      req.write(JSON.stringify(body));
    }
    req.end();
  });
}

async function uploadFile(fileObj) {
  const contentBase64 = fs.readFileSync(fileObj.fullPath).toString('base64');
  const apiPath = `/repos/${REPO_OWNER}/${REPO_NAME}/contents/${encodeURIComponent(fileObj.relPath).replace(/%2F/g, '/')}`;

  // Check if file already exists to get SHA
  let sha = null;
  try {
    const check = await githubRequest('GET', apiPath + `?ref=${BRANCH}`);
    if (check.status === 200 && check.data && check.data.sha) {
      sha = check.data.sha;
    }
  } catch (err) {
    // Continue if file doesn't exist
  }

  const payload = {
    message: `Deploy ${fileObj.relPath} (Siana Jeddah VIP)`,
    content: contentBase64,
    branch: BRANCH
  };
  if (sha) {
    payload.sha = sha;
  }

  const result = await githubRequest('PUT', apiPath, payload);
  if (result.status === 200 || result.status === 201) {
    console.log(`  [✔] ${fileObj.relPath}`);
    return true;
  } else {
    console.error(`  [✖] Failed: ${fileObj.relPath} (Status ${result.status})`);
    if (result.data && result.data.message) {
      console.error(`      Message: ${result.data.message}`);
    }
    return false;
  }
}

async function main() {
  console.log(`\n======================================================`);
  console.log(`🚀 Uploading to https://github.com/${REPO_OWNER}/${REPO_NAME} [branch: ${BRANCH}]`);
  console.log(`======================================================\n`);

  // Verify auth user
  const userCheck = await githubRequest('GET', '/user');
  if (userCheck.status === 200 && userCheck.data && userCheck.data.login) {
    console.log(`Authenticated as GitHub user: @${userCheck.data.login}`);
    if (REPO_OWNER === 'zayndaric' && userCheck.data.login !== 'zayndaric') {
      REPO_OWNER = userCheck.data.login;
      console.log(`Using your account username as repo owner: @${REPO_OWNER}`);
    }
  } else if (userCheck.status === 401) {
    console.error(`[!] Authentication failed: Your GitHub Token is invalid or expired.`);
    process.exit(1);
  }

  // Check repo existence
  const repoCheck = await githubRequest('GET', `/repos/${REPO_OWNER}/${REPO_NAME}`);
  if (repoCheck.status === 404) {
    console.error(`\n[!] Repository https://github.com/${REPO_OWNER}/${REPO_NAME} does not exist.`);
    console.log(`Please create it first on GitHub: https://github.com/new`);
    console.log(`Set the repository name to '${REPO_NAME}', then run this script again.\n`);
    process.exit(1);
  }

  const files = getAllFiles(PROJECT_DIR);
  console.log(`\nFound ${files.length} project files to upload.\n`);

  let successCount = 0;
  for (const file of files) {
    const ok = await uploadFile(file);
    if (ok) successCount++;
  }

  console.log(`\n======================================================`);
  console.log(`🎉 Finished: ${successCount}/${files.length} files uploaded successfully!`);
  console.log(`🔗 Repository: https://github.com/${REPO_OWNER}/${REPO_NAME}`);
  console.log(`🚀 Deploy on Vercel: https://vercel.com/new/import?s=https://github.com/${REPO_OWNER}/${REPO_NAME}`);
  console.log(`======================================================\n`);
}

main().catch(err => {
  console.error('Fatal error during upload:', err);
});
