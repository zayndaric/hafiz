@echo off
title صيانة جدة VIP - فتح الموقع
cd /d "%~dp0"
start "" "index.html"
